#include<stdio.h> 

int main(){
    int length=3, breadth=8;
    int area = length * breadth;
    printf("The area of this rectangele is %d", area);
    return 0;
}
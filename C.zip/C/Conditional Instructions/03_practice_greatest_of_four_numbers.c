#include<stdio.h> 

int main(){
    int a, b, c, d;
    printf("Enter the value of a\n");
    scanf("%d", &a);

    printf("Enter the value of b\n");
    scanf("%d", &b);

    printf("Enter the value of c\n");
    scanf("%d", &c);

    printf("Enter the value of d\n");
    scanf("%d", &d);

    if(a>b){
        if(a>c){
            if(a>d){
                printf("The greatest number is %d", a);
            }
            else{
                printf("The greatest number is %d", d);
            }
        }
        if(c>d){
                printf("The greatest number is %d", c);  
            }
            else{
                printf("The greatest number is %d", d);
            }
    }
    else{
        if(b>c){
            if(b>d){
                if(a>d){
                    printf("The greatest number is %d", b);
                }
                else{
                    printf("The greatest number is %d", d);
                }
            }
        }
        else{
           if(c>d){
                    printf("The greatest number is %d", c);
                }
                else{
                    printf("The greatest number is %d", d);
                }
        }
    }
    return 0;
}
#include<stdio.h> 

int main(){
    int a;
    printf("Enter the number\n", a);
    scanf("%d", &a);
    for(int a;a;a++){
        printf("A X %d = %d\n", 1*a);
    }
    return 0;
}
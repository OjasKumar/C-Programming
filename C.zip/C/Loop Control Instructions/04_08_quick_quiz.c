#include<stdio.h> 

int main(){
    int i = 0;
    int n;
    printf("Enter the value of n \n");
    scanf("%d", &n);

    for ( i = 0; i < 10; i++)
    {
        printf("The number is %d\n", i+1);
    }
    

    return 0;
}
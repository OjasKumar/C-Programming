#include <stdio.h>

int main()
{
    printf("hello ");
    printf("world\n");
    int a = 1;
    // Loops are used to repeat similar parts of a code 
    // snippet efficiently
    // (
    // printf("%d\n", a);
    // a++;) =---> 100 times

    return 0;
}
#include<stdio.h>
void multiply(int *number); 

int main(){
    int number;
    printf("Enter the number\n", number);
    scanf("%d", &number);
    multiply(&number);
    return 0;
}

void multiply(int *number){
    int temp;
    temp = *number;
    printf("The number multiplied by 10 is %d\n", temp*10);

}
    

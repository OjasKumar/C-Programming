#include<stdio.h> 
int multiply(int number);

int main(){
    int number;
    printf("Enter the number\n", number);
    scanf("%d", &number);
    printf("The number multiplied by 10 is %d", number *10);
    return 0;
}

int multiply(int number){
    int c;
    c = 10 * number;
}
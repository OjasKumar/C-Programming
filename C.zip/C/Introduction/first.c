#include<stdio.h> 

int main(){
    printf("Hello I am learning C with Harry");
    return 0;
}
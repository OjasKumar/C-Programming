#include<stdio.h> 
#include<math.h> 

int main(){
    int side;
    printf("Enter the value of side\n");
    scanf("%d", &side);
    printf("The value of area is %d\n",(int)pow(side, 2));
    return 0;
}
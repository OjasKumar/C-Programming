#include <stdio.h>
void goodMorning();
void goodAfternoon();
void goodNight();

int main(){
    goodMorning();
    goodAfternoon();
    goodNight();
    return 0;
}

void goodMorning(){
    printf("Good Morning Ojas\n");
}
void goodAfternoon(){
    printf("Good Afternoon Ojas\n");
}
void goodNight(){
    printf("Good Night Ojas\n");
}
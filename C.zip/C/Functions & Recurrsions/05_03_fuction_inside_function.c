#include <stdio.h>
void goodMorning();
void goodAfternoon();
void goodNight();

int main(){
    goodMorning();
    return 0;
}

void goodMorning(){
    printf("Good Morning Ojas\n");
    goodAfternoon();
}
void goodAfternoon(){
    printf("Good Afternoon Ojas\n");
    goodNight();    
}
void goodNight(){
    printf("Good Night Ojas\n");
}
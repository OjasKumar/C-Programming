#include<stdio.h> 

int main(){
    float c, fh;
    printf("Enter the temperature in celsius\n", c);
    scanf("%f", &c);

    fh = (c * 1.8) + 32;

    printf("The temperature in fahrenheit is %f", fh);
    return 0;
}
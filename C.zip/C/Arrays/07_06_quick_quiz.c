#include<stdio.h> 

int main(){
    int i = 45;
    int *ptr = &i;
    printf("The value of ptr is %u\n", ptr);
    ptr = ptr + 10;
    printf("The value of ptr is %u\n", ptr);

    int u = 45;
    int *ptr = &u;
    printf("The value of ptr is %u\n", ptr);
    ptr = ptr - 10;
    printf("The value of ptr is %u\n", ptr);

    int numbers[5] = {1,2,3,4,5};
    int *ptr1 = &numbers[0];
    int *ptr2 = &numbers[4];

    printf("%d\n", ptr2 - ptr1);

    int num1 = 10;
    int num2 = 20;
    int *ptr1 = &num1;
    int *ptr2 = &num1;

    printf("%d\n",ptr1 == ptr2);

    return 0;
}


#include<stdio.h> 

int main(){
    int name = 3;
    int age = 5;

    int details[3][5];
    for(int i=0; i<name; i++){
        for(int j=0; j<age; j++){
            printf("Enter the details of name %d and age %d\n", i+1, j+1);
            scanf("%d", &details[i][j]);
        }
    }

    for(int i=0; i<name; i++){
        for(int j=0; j<age; j++){
            printf("The details of name %d and age %d is :%d\n", i+1, j+1, details[i][j]);
        }
    }
    return 0;
}